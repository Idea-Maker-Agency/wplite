<div class="copyright py-2">
  <div class="container">
    <p class="mb-0 text-center">
      <a href="<?php echo site_url(); ?>">WPLite</a>

      <span>&copy; <?php echo date( 'Y' ); ?> | All Rights Reserved.</span>

      <a href="#">Terms & Conditions</a> |
      <a href="#">Privacy Policy</a> |
      <a href="#">Credits</a>
    </p>
  </div>
</div>
