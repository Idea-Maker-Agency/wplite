<a
  href="<?php echo site_url(); ?>"
  class="footer-logo fs-2 mb-4 d-block">
  WPLite
</a>

<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aut, ut quia labore earum itaque et, vel hic porro</p>
