<nav class="header navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a
       href="<?php echo site_url(); ?>"
      class="navbar-brand">WPLite</a>

    <?php get_template_part( 'lib/templates/structure/header/header', 'navigation' ); ?>
  </div>
</nav>
