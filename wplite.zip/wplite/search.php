<?php
/**
 * The template for displaying search results pages.
 *
 * @package    WPLite
 * @subpackage Templates
 * @author     Idea Maker
 * @since      1.0.0
 */

get_header();
?>

<?php
get_footer();
